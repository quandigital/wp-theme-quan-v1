<?php
	//socialmedia
?>

	<h2><?php _e( 'Push the boat out &ndash; let others do the talking about just how wonderful you are', 'quan' ); ?></h2>
	
	<p id="soc-content-1"><?php _e( 'We use social networks on both an occupational and personal basis, and come into contact with the relentless amounts of content that streams through the internet every day.<br />We can supply great content, which will be heard and gladly shared. Content that is fresh, well written and engaging – and which lets the world know about your great work. It can be done on Facebook, via Twitter, YouTube or other platforms.', 'quan' ); ?><br />
	<?php _e( 'Ultimately, this is rated in a very positive manner by search engines such as Google. Custom social media strategies, realised with the utmost precision, generate both attention and traffic.', 'quan' ); ?></p>
