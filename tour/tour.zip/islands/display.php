<?php
	//display/cpc
?>

	<h2><?php _e( 'Full speed ahead with CPC', 'quan' ); ?></h2>

	<p id="cpc-content"><?php _e( 'You approach your customers directly. As a short-term investment, AdWords is the boost you need for your site. You only pay for the users who come to your website via the advertisement. AdWords campaigns offer an excellent basis for cost-benefit analyses of your online activities and only bring you the customers who are looking for your product. In other words – exactly the people you want to find you.<br />Your site is optimised, social media and blogger outreach strategies are kicking in – we use AdWords on your behalf, to better achieve your target conversion goals.', 'quan' ); ?></p>