<?php
	//agency/outreach/pr
?>

	<div id="shipwheel">
		<?php include( './images/shipwheel.svg' ); ?>
	</div>

	<h2><?php _e( 'Ship ahoy &ndash; We are at the helm for you', 'quan' ); ?></h2>

	<p id="service-content-1"><?php _e( 'Your agency requires expertise for a specific project? You’re in need of optimised content? Maybe you’re already working with an agency and need support for a comprehensive venture?', 'quan' ); ?></p>

	<p id="service-content-2"><?php _e( 'Our products are your products. Quan Digital offers white label solutions, allowing you to resell our products and services as your own and thereby expanding your portfolio.<br />We support you and your agency in across a wide variety of fields. And of course, with a 100% anonymity assurance.', 'quan' ); ?></p>