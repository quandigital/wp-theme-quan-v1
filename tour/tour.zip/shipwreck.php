<?php
	//if the browser is being resized we have to reload the page
	// let's see how that works out
?>

	<div id="shipwreck" class="modal">
		<h2>&middot;&middot;&middot;---&middot;&middot;&middot; &middot;&middot;&middot;---&middot;&middot;&middot; &middot;&middot;&middot;---&middot;&middot;&middot;</h2>
		<p><?php _e( "Whoops! Something has gone wrong. We'll reload the page...", 'quan' ); ?>.</p>
		<?php include( './images/shipwreck.svg' ); ?>
	</div>