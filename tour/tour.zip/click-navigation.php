<div id="clicknav" data-message="<?php __( 'Get on Board!', 'text on navigation after last island', 'quan' ); ?>">
	<i class="ion-ios7-arrow-down" id="start-navigation"></i>
</div>